# SGPSM
Similarity measures for generalized propensity score matching (SGPSM) is a propensity score method for multiple treatments matching. It can reduce confounding effects and provide unbiased average treatment effects for multiple treated groups, similar to other propensity score methods. This R code implements 3-way SGPSM for propensity score matching with three treated groups. 

If you have any comments or suggestions for this code, please feel free to contact me. I will work on adding features in the future. You can reach me through github (https://github.com/Epicode10/SGPSM.git), email, or facebook (@SGPSM).

# Usage

### Example:
```diff
data1 <- read.csv("~/data.csv")

source("~/3way_SGPSM.R")

matched_data <- SGPSM_3way(df = data1, treat_group = "trt", gpsm = c("X0","X1","X2"), algo = "cosine", caliper = 0.1)
head(matched_data)
```

df: &emsp; File name.<br>
treat_group: &emsp; Variable for treatment groups.<br>
gpsm: &emsp; Variables for generalized propensity score (input column name of propensity scores vector).<br>
algo: &emsp; Algorithm of cosine, euclidean, manhattan.<br>
caliper: &emsp; Caliper.<br>


# Dependencies
R package: dplyr >= 1.0.8, proxyC >= 0.2.4
