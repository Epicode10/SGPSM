####################################################################################
# Description: three-way generalized propensity score matching
# Algorithm: similarity measures for generalized propensity score matching (SGPSM) 
# Version: 1.0
# Created: 2023/3/13

# Note: This is old version for GPSM. Please use updated version (see GPSM_v1.0.R)
####################################################################################


data1 <- read.csv("~/data.csv")


source("~/3way_SGPSM.R")


matched_data <- SGPSM_3way(
  df = data1, # file name
  treat_group = "trt",
  gpsm = c("X0","X1","X2"),  # input column name of propensity scores vector
  algo = "euclidean",   # cosine, euclidean, manhattan
  caliper = 0.1  
)



