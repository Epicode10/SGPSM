####################################################################################
# Description: three-way generalized propensity score matching
# Algorithm: similarity measures for generalized propensity score matching (SGPSM) 
# Version: 1.0
# Created: 2023/3/13

# Note: This is old version for GPSM. Please use updated version (see GPSM_v1.0.R)
####################################################################################


SGPSM_3way <- function(
    df,
    treat_group,
    gpsm,
    algo,
    caliper
){


##############################
# required packages
##############################

library(dplyr)
library(proxyC)


##############################
# similarity
##############################

df <- df %>% mutate(PID = row_number())  

set.seed(0)

df_id <- data.frame(PID = df$PID, group = df[,treat_group])
treat <- unique(df_id$group)

dt <- df[,gpsm]
dt <- data.matrix(dt)

if(algo == "cosine"){
  dist.mt <- proxyC::simil(dt, method = algo)
  dist.mt <- data.matrix(dist.mt)
  dist.mt <- data.frame(dist.mt)
}else{
  dist.mt <- proxyC::dist(dt, method = algo)
  dist.mt <- data.matrix(dist.mt)
  dist.mt <- data.frame(dist.mt)
}



##############################
# GPSM
##############################

### preparation:

ref_mt <- data.frame(table(df_id$group))
ref_mt$Var1 <- as.numeric(as.character(ref_mt$Var1))
ref <- ref_mt$Var1[ref_mt$Freq == min(ref_mt$Freq)]

base <- df_id[df_id$group == ref, ]
compare <- df_id[-base$PID, ] 

dist.mt$PID <- rownames(dist.mt)

matched <- data.frame()
target <- base
pool <- compare





### do loop part:


if(algo == "cosine"){


for(i in 1:min(ref_mt$Freq)){
  cat("\r","Process rate: ", round(i/min(ref_mt$Freq)*100,2), '%     ') # process rate
  
  selected <- target[i,] #
  dist.mt2 <- merge(pool, dist.mt, by="PID")
  
  col.index <- append(c(1,2), (selected[,1]+2))
  dist.mat.col <- dist.mt2[, col.index]
  names(dist.mat.col)[3] <- "similarity" 
  
  
  dist_AB_AC <- dist.mat.col %>% group_by(group) %>% filter(similarity == max(similarity))
  dist_AB_AC <- unique(dist_AB_AC, by="group")
  dist_AB_AC <- as.data.frame(dist_AB_AC)
  
  cab0 <- dist_AB_AC %>% mutate(check = ifelse((1-similarity) <= caliper, 1,0 ))  # caliper
  check_cab0 <- sum(cab0$check)
  
  if(length(dist_AB_AC$group) != 2 & check_cab0 !=2){ next }else{
    
    col.index2 <- append(c(1,2), dist_AB_AC[1,1]+2)
    dist_BC <- dist.mt2[dist.mt2$PID == dist_AB_AC[2,1], col.index2]
    dist_BC[,1] <- NA
    dist_BC[,2] <- NA
    names(dist_BC)[3] <- "similarity" 
    
    pairs <- bind_rows(selected, dist_AB_AC, dist_BC)
    
    pairs$pair <- i  #
    
    
    cab <- 1- dist_BC[1,3]            # similarity for B & C
    
    check_cab <- sum(cab <= caliper)  # caliper
    
    if(check_cab==1){
      matched <- rbind(matched, pairs)
      pool <- pool[!(pool$PID %in% dist_AB_AC$PID),]
    }else{rm(pairs)}
  }
  
}


### get data

matched_data <- merge(matched[, c(1,4)], df, by="PID")
return(matched_data)


}else{


for(i in 1:min(ref_mt$Freq)){
  cat("\r","Process rate: ", round(i/min(ref_mt$Freq)*100,2), '%     ') # process rate
  
  selected <- target[i,] #
  dist.mt2 <- merge(pool, dist.mt, by="PID")
  
  col.index <- append(c(1,2), (selected[,1]+2))
  dist.mat.col <- dist.mt2[, col.index]
  names(dist.mat.col)[3] <- "similarity" 
  
  
  dist_AB_AC <- dist.mat.col %>% group_by(group) %>% filter(similarity == min(similarity))
  dist_AB_AC <- unique(dist_AB_AC, by="group")
  dist_AB_AC <- as.data.frame(dist_AB_AC)
  
  cab0 <- dist_AB_AC %>% mutate(check = ifelse((similarity) <= caliper, 1,0 ))  # caliper
  check_cab0 <- sum(cab0$check)
  
  if(length(dist_AB_AC$group) != 2 & check_cab0 !=2){ next }else{
    
    col.index2 <- append(c(1,2), dist_AB_AC[1,1]+2)
    dist_BC <- dist.mt2[dist.mt2$PID == dist_AB_AC[2,1], col.index2]
    dist_BC[,1] <- NA
    dist_BC[,2] <- NA
    names(dist_BC)[3] <- "similarity" 
    
    pairs <- bind_rows(selected, dist_AB_AC, dist_BC)
    
    pairs$pair <- i  #
    
    
    cab <- dist_BC[1,3]               # similarity for B & C
    
    check_cab <- sum(cab <= caliper)  # caliper
    
    if(check_cab==1){
      matched <- rbind(matched, pairs)
      pool <- pool[!(pool$PID %in% dist_AB_AC$PID),]
    }else{rm(pairs)}
  }
  
}


### get data

matched_data <- merge(matched[, c(1,4)], df, by="PID")
return(matched_data)

}


}










